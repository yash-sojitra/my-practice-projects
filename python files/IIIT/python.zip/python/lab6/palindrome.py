a = input("enter a name: \n")

if a==a[::-1]:
    print("Palindrome")
else:
    print("Not Palindrome")  

