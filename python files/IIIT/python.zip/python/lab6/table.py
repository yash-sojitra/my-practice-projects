a = int(input("Enter a number to generate its table : \n"))

for i in range(1, 11):
    print(a , "x" , i , "=" , a*i)