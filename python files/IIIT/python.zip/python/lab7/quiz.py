# def bitwise(x,y):

#     print(bin(x),bin(y))
#     print(bin(~x))

#     z = ~x^y
#     print(bin(z))
#     p = z&(z+10)
#     print(bin(p))
#     return p, z


# print(bitwise(20, 16))

print(bin(~1))
print(bin(~2))
print(bin(~3))
print(bin(~4))
print(bin(~5))
print(bin(~6))
print(bin(~7))
print(bin(~8))
print(bin(~9))
print(bin(~10))
print(bin(~11))
# print(bin(~12))