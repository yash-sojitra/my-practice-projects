a  =input("Enter a string with puctuations : \n")
b= ".,;:'/\<>?\{\}[]!@#$%^&*()_+=-`~\""

print(a.translate({ord(i): " " for i in b}))