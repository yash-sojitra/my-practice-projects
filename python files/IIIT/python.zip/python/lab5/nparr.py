import numpy as np

arr = np.array([4,6,2,4,6,3,2])

print(arr)
np.insert(arr, 1, 5,)
print(arr)