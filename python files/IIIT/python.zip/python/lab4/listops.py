lang = ["python", "java", "c", "html", "css"]

lang.insert(5,"javascript")
print(lang,"\n")

lang.remove("c")
print(lang,"\n")

lang.append("c")
print(lang,"\n")

print(len(lang),"\n")

lang.pop()
print(lang,"\n")

lang.clear()
print(lang,"\n")