a = int(input("enter first number :\n"))
b = int(input("enter second number :\n"))


print("minimum value among the both of them is :")
print(a) if a<=b else print(b)