s1 = "This is a classroom."
s2 = " you are a student."
s = s1 + s2

print("the result of concatenation is :\n",s)



print("\nextracted sentences from the concatenated string is :\n",s.split("."))



