a = "hello"
b = " world"

c = a + b

print(c)

print(c.split())

print(c.split()[1])