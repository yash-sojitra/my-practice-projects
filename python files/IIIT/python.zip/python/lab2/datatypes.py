print("\nthis program shows different datatypes of different variables\n")

a= 2
b=4.6
c=True
d = "yash"
e = bin(10)
f = complex(1,1)
g = hex(11)
h = oct(12)

print(type(a))
print(a, "\n")
print(type(b))
print(b, "\n")
print(type(c))
print(c, "\n")
print(type(d))
print(d, "\n")
print(type(e))
print(e, "\n")
print(type(f))
print(f, "\n")
print(type(g))
print(g, "\n")
print(type(h))
print(h, "\n")
