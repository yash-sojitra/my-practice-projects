a = int(input("enter a number :"))

result = print("even") if a%2 == 0 else print("odd")