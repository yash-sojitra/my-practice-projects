a = 5

if (a%2 == 0):
    print('number is even')
else:
    print('number is odd')