a = 1
b = int(input('enter the number to calculate its factorial :'))


for i in range(1,b + 1):
    a = a*i

print(a)