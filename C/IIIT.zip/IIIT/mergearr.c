#include <stdio.h>

int main()
{
    int arr1[] = {2,4,5,6};
    int n1 = sizeof(arr1)/sizeof(arr1[0]);
    int arr2[] = {3,6,7,8,8,9};
    int n2 = sizeof(arr2)/sizeof(arr2[0]);

    int ans[n1 + n2];
    int n = 0;
    int i = 0, j = 0;

    while(i+j<n1+n2)
    {
        if(arr1[i]<arr2[j])
        {
            arr
        }
    }



    return 0;
}