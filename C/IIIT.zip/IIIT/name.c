#include <stdio.h>

int main()
{
    printf("yash sojitra \n");
    printf("ui22ec72 \n");
    printf("ECE IIITS \n");
    return 0;
}